package com.dineout.code.reporting.EmailSender;/*
public class TableRow {
    Object[] cells;

    public TableRow(Object[] cells) {
        this.cells = cells;
    }

}
*/
