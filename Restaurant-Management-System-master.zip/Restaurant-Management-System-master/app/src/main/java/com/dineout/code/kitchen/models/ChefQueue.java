package com.dineout.code.kitchen.models;

import java.util.ArrayList;

public class ChefQueue {
    private ArrayList<OrderDetailsDb> dishes;
}
